import pandas as pd
from sklearn.model_selection import train_test_split
from lightgbm import LGBMClassifier
import joblib
from utils.preprocessing import preprocess_train

# Load dataset
df = pd.read_csv('data/crime_dataset_500k.csv')

X, y = preprocess_train(df)

# Split and train
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
model = LGBMClassifier()
model.fit(X_train, y_train)

# Save model
joblib.dump(model, 'model/crime_model.pkl')
print("Model trained and saved.")
