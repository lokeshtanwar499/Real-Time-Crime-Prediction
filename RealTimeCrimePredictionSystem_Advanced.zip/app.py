from flask import Flask, request, jsonify
import joblib
import pandas as pd
from utils.preprocessing import preprocess_input

app = Flask(__name__)
model = joblib.load('model/crime_model.pkl')

@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json()
    df = pd.DataFrame([data])
    processed = preprocess_input(df)
    prediction = model.predict(processed)[0]
    return jsonify({'predicted_crime': prediction})

if __name__ == '__main__':
    app.run(debug=True)
