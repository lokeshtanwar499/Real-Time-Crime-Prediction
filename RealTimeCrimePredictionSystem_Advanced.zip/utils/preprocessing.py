import pandas as pd
from sklearn.preprocessing import LabelEncoder

def preprocess_train(df):
    df = df.dropna()
    df['hour'] = pd.to_datetime(df['timestamp']).dt.hour
    df['day_of_week'] = pd.to_datetime(df['timestamp']).dt.dayofweek
    df = df[['latitude', 'longitude', 'hour', 'day_of_week', 'crime_type']]
    le = LabelEncoder()
    df['crime_type'] = le.fit_transform(df['crime_type'])
    X = df.drop('crime_type', axis=1)
    y = df['crime_type']
    return X, y

def preprocess_input(df):
    df['hour'] = pd.to_datetime(df['timestamp']).dt.hour
    df['day_of_week'] = pd.to_datetime(df['timestamp']).dt.dayofweek
    return df[['latitude', 'longitude', 'hour', 'day_of_week']]
